import java.io.IOException;

public interface Crawler {
	public void craw() throws IOException;
}
