package com.example.legen.readnews.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by legen on 3/23/2017.
 */

public class FragmentGiaoDuc extends Fragment {
}
