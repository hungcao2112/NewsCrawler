package com.example.legen.readnews.library;

import android.view.View;

/**
 * Created by legen on 3/30/2017.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
